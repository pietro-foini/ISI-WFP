# Python packages

Into this folder, we have stored some custom python modules. For more details abouth them, it is recommended to read the documentation inside the respective files.